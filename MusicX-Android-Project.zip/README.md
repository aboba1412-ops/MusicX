# MusicX — Android music player

Android source project built with Kotlin, Jetpack Compose and AndroidX Media3.

## Included
- Offline playback of audio files selected from device storage.
- Multi-file audio import.
- Music library list.
- Home screen and mini-player.
- Animated floating waveform navigation.
- Lyrics/notes editor screen.
- Albums/collections starter screen.
- Listening insights screen starter.

## Important implementation status
This package is an Android Studio source project, **not a compiled APK**.
The app label and application ID are MusicX (`com.musicx.player`).

Not yet implemented: persistent lyrics and albums, album assignment, cover video/media, full listening-history analytics, background playback service and notification controls, online music catalog search/import, and interactive seek bar. Internet downloads should only be added for sources that explicitly permit downloading; this project does not bypass streaming or copyright restrictions.

## Build an APK
1. Open the `MusicX` folder in Android Studio.
2. Install Android SDK 35 and JDK 17 when prompted.
3. Sync Gradle.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

A GitHub Actions workflow is included at `.github/workflows/build.yml`. Push the project to a GitHub repository and run the **Build MusicX APK** workflow; download the `MusicX-debug-apk` artifact from the workflow run.

Minimum Android version: Android 8.0 (API 26).
