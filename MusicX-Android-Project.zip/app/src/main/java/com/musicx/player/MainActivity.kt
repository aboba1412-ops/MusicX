package com.musicx.player

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

private val Ink = Color(0xFF090B14)
private val Panel = Color(0xFF151A2A)
private val Violet = Color(0xFF9B7BFF)
private val Cyan = Color(0xFF55E6D1)
private val Muted = Color(0xFF9299B2)

data class Song(val uri: Uri, val title: String, val artist: String = "Unknown artist")

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent { ResonanceApp(player) }
    }
    override fun onDestroy() { player.release(); super.onDestroy() }
}

@Composable
fun ResonanceApp(player: ExoPlayer) {
    var songs by remember { mutableStateOf(listOf<Song>()) }
    var selected by remember { mutableIntStateOf(0) }
    var tab by remember { mutableStateOf("Home") }
    var lyrics by remember { mutableStateOf("") }
    var albumName by remember { mutableStateOf("") }
    var showAlbumDialog by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(false) }
    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val added = uris.map { uri ->
            runCatching { }.getOrNull()
            Song(uri, uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "Imported track")
        }
        songs = songs + added
        added.forEach { runCatching { player.addMediaItem(MediaItem.fromUri(it.uri)) } }
        if (player.mediaItemCount > 0 && player.currentMediaItemIndex < 0) player.prepare()
    }

    LaunchedEffect(player) {
        while (true) {
            isPlaying = player.isPlaying
            duration = player.duration.coerceAtLeast(0)
            position = player.currentPosition.coerceAtLeast(0)
            kotlinx.coroutines.delay(500)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Violet, secondary = Cyan,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF17152B), Ink, Ink))
        )) {
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(22.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("MUSICX", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Text(tab, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = { importLauncher.launch(arrayOf("audio/*")) }) {
                        Icon(Icons.Default.Add, null, tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                }
                Spacer(Modifier.height(20.dp))
                when (tab) {
                    "Home" -> HomeContent(songs.size, songs.getOrNull(selected), isPlaying, position, duration,
                        onPlay = { if (player.mediaItemCount > 0) { if (player.isPlaying) player.pause() else { if (player.playbackState == Player.STATE_IDLE) player.prepare(); player.play() } } },
                        onImport = { importLauncher.launch(arrayOf("audio/*")) },
                        onLyrics = { tab = "Lyrics" })
                    "Library" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Your tracks", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            Text("${songs.size} tracks", color = Muted, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        if (songs.isEmpty()) EmptyState("Your library is waiting", "Import audio files stored on your phone.") {
                            importLauncher.launch(arrayOf("audio/*"))
                        } else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(songs) { song ->
                                SongRow(song, songs.indexOf(song) == selected) {
                                    selected = songs.indexOf(song)
                                    player.seekTo(selected, 0)
                                    player.prepare()
                                    player.play()
                                }
                            }
                        }
                    }
                    "Albums" -> {
                        Text("Your collections", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(12.dp))
                        EmptyState("Make it yours", "Create album collections and organize your imported tracks.") {
                            showAlbumDialog = true
                        }
                        if (albumName.isNotBlank()) Text("✦  $albumName", color = Cyan, modifier = Modifier.padding(top = 14.dp))
                    }
                    "Lyrics" -> {
                        Text("Lyrics & notes", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Text(songs.getOrNull(selected)?.title ?: "No track selected", color = Muted, fontSize = 13.sp)
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = lyrics, onValueChange = { lyrics = it },
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            placeholder = { Text("Paste or write the lyrics here…") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Violet, unfocusedBorderColor = Muted,
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White
                            )
                        )
                        Text("Lyrics are editable in this session. Persistent per-track storage is planned for the next build.",
                            color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                    }
                    "Stats" -> StatsContent(songs.size, position)
                }
                Spacer(Modifier.height(126.dp))
            }

            // Floating mini-player and animated waveform navigation bar
            Column(Modifier.align(Alignment.BottomCenter).padding(horizontal = 12.dp, vertical = 10.dp)) {
                if (songs.isNotEmpty()) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                            .background(Panel.copy(alpha = .96f)).clickable { tab = "Home" }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp))
                            .background(Brush.linearGradient(listOf(Violet, Cyan))),
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.MusicNote, null, tint = Ink)
                        }
                        Column(Modifier.weight(1f).padding(start = 10.dp)) {
                            Text(songs.getOrNull(selected)?.title ?: "MusicX", maxLines = 1, fontWeight = FontWeight.SemiBold)
                            Text(songs.getOrNull(selected)?.artist ?: "Ready to play", color = Muted, fontSize = 11.sp)
                        }
                        IconButton(onClick = {
                            if (player.isPlaying) player.pause() else {
                                if (player.mediaItemCount > 0) {
                                    if (player.playbackState == Player.STATE_IDLE) player.prepare()
                                    player.play()
                                }
                            }
                        }) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Cyan) }
                    }
                    Spacer(Modifier.height(9.dp))
                }
                WaveBar(tab) { tab = it }
            }
            if (showAlbumDialog) {
                AlertDialog(
                    onDismissRequest = { showAlbumDialog = false },
                    title = { Text("New collection") },
                    text = { OutlinedTextField(value = albumName, onValueChange = { albumName = it }, label = { Text("Album name") }) },
                    confirmButton = { TextButton(onClick = { showAlbumDialog = false }) { Text("Create") } },
                    dismissButton = { TextButton(onClick = { showAlbumDialog = false }) { Text("Cancel") } }
                )
            }
        }
    }
}

@Composable
fun HomeContent(count: Int, song: Song?, playing: Boolean, pos: Long, dur: Long,
                onPlay: () -> Unit, onImport: () -> Unit, onLyrics: () -> Unit) {
    Text("YOUR SOUND. YOUR SPACE.", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
    Spacer(Modifier.height(12.dp))
    Box(Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(28.dp))
        .background(Brush.linearGradient(listOf(Color(0xFF5540A5), Color(0xFF1A9C9A), Color(0xFF171A2B)))),
        contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.GraphicEq, null, tint = Color.White, modifier = Modifier.size(58.dp))
            Text("SOUND IN MOTION", color = Color.White, fontSize = 12.sp, letterSpacing = 3.sp)
            Text("$count tracks in your library", color = Color.White.copy(alpha = .75f), fontSize = 12.sp)
        }
    }
    Spacer(Modifier.height(20.dp))
    Text("Now playing", color = Muted, fontSize = 12.sp)
    Text(song?.title ?: "Choose your first track", fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    Text(song?.artist ?: "Import music to get started", color = Muted, fontSize = 13.sp)
    Spacer(Modifier.height(14.dp))
    Slider(value = if (dur > 0) pos.toFloat().coerceIn(0f, dur.toFloat()) else 0f,
        onValueChange = {}, valueRange = 0f..(dur.toFloat().coerceAtLeast(1f)),
        colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Violet))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(formatTime(pos), color = Muted, fontSize = 11.sp)
        Text(formatTime(dur), color = Muted, fontSize = 11.sp)
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
        IconButton(onClick = onLyrics) { Icon(Icons.Default.Lyrics, null, tint = Muted) }
        Spacer(Modifier.width(22.dp))
        IconButton(onClick = onPlay, modifier = Modifier.size(64.dp).clip(CircleShape).background(Violet)) {
            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.width(22.dp))
        Icon(Icons.Default.Shuffle, null, tint = Muted)
    }
    Spacer(Modifier.height(10.dp))
    OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Default.FileOpen, null)
        Spacer(Modifier.width(8.dp))
        Text("Import music")
    }
}

@Composable
fun SongRow(song: Song, active: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
        .background(if (active) Violet.copy(alpha = .18f) else Panel)
        .clickable(onClick = onClick).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.MusicNote, null, tint = if (active) Cyan else Violet)
        Column(Modifier.weight(1f).padding(start = 10.dp)) {
            Text(song.title, maxLines = 1, fontWeight = FontWeight.Medium)
            Text(song.artist, color = Muted, fontSize = 11.sp)
        }
        if (active) Icon(Icons.Default.Equalizer, null, tint = Cyan)
    }
}

@Composable
fun EmptyState(title: String, subtitle: String, action: () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Panel).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.LibraryMusic, null, tint = Violet, modifier = Modifier.size(38.dp))
        Spacer(Modifier.height(10.dp))
        Text(title, fontWeight = FontWeight.SemiBold)
        Text(subtitle, color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Button(onClick = action) { Text("Get started") }
    }
}

@Composable
fun StatsContent(count: Int, listeningMs: Long) {
    Text("Listening insights", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(14.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatCard("Library", "$count", "tracks", Modifier.weight(1f))
        StatCard("This session", formatTime(listeningMs), "elapsed", Modifier.weight(1f))
    }
    Spacer(Modifier.height(14.dp))
    Text("Your listening timeline", color = Muted, fontSize = 12.sp)
    Spacer(Modifier.height(12.dp))
    Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(20.dp)).background(Panel).padding(16.dp)) {
        Canvas(Modifier.fillMaxSize()) {
            val bars = listOf(.25f,.45f,.34f,.7f,.52f,.9f,.6f,.4f,.78f,.56f,.85f,.32f,.62f,.46f,.72f,.4f)
            val w = size.width / (bars.size * 1.7f)
            bars.forEachIndexed { i, v ->
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(Cyan, Violet)),
                    topLeft = Offset(i * w * 1.7f, size.height * (1-v)),
                    size = androidx.compose.ui.geometry.Size(w, size.height * v),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(w)
                )
            }
        }
    }
    Text("Detailed daily and per-track analytics will build as listening history is added.",
        color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
}

@Composable
fun StatCard(label: String, value: String, suffix: String, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(Panel).padding(16.dp)) {
        Text(label, color = Muted, fontSize = 11.sp)
        Text(value, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Cyan)
        Text(suffix, color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun WaveBar(selected: String, onSelect: (String) -> Unit) {
    val tabs = listOf("Home", "Library", "Albums", "Lyrics", "Stats")
    val infinite = rememberInfiniteTransition(label = "wave")
    val phase by infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "phase")
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
        .background(Color(0xF21A1D30)).padding(horizontal = 5.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
        tabs.forEachIndexed { index, tab ->
            val active = selected == tab
            Column(Modifier.weight(1f).clip(RoundedCornerShape(18.dp))
                .background(if (active) Violet.copy(alpha = .22f) else Color.Transparent)
                .clickable { onSelect(tab) }.padding(vertical = 5.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                Canvas(Modifier.width(34.dp).height(19.dp)) {
                    val count = 9
                    for (i in 0 until count) {
                        val h = if (active) (5 + 12 * kotlin.math.abs(kotlin.math.sin((i * .8f + phase * 6.28f).toDouble())).toFloat()) else 5f
                        drawRoundRect(
                            color = if (active) Cyan else Muted,
                            topLeft = Offset(i * size.width / count + 1, (size.height-h)/2),
                            size = androidx.compose.ui.geometry.Size(2.4f, h),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(3f)
                        )
                    }
                }
                Text(tab, color = if (active) Color.White else Muted, fontSize = 9.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}

fun formatTime(ms: Long): String {
    val sec = (ms.coerceAtLeast(0) / 1000)
    return "%d:%02d".format(sec / 60, sec % 60)
}
